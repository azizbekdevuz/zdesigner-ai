import HomePage from "../page";

export default function About() {
  return <HomePage currentPage="about" />;
}
