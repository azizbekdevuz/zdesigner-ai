import HomePage from "../page";

export default function History() {
  return <HomePage currentPage="history" />;
}
