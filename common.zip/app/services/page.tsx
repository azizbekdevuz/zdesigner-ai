import HomePage from "../page";

export default function Services() {
  return <HomePage currentPage="services" />;
}
