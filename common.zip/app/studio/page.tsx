import HomePage from "../page";

export default function Studio() {
  return <HomePage currentPage="studio" />;
}
