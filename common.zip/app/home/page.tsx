import HomePage from "../page";

export default function Home() {
  return <HomePage />;
}
